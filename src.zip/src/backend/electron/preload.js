//WIP file, to preload JQ
  const preloadJQ = () => {
    const path = require('path')
    window.addEventListener('load', () => {
      //inject jquery to page
      window.$ = window.jQuery = require(path.join(__dirname, "../../../node_modules/jquery/dist/jquery.js"));
    });
  };

module.exports = preloadJQ;
