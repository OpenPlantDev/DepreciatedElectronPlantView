import * as React from "react";

class DwgList extends React.Component {
  public render() {
    const title = "DwgList";
    return <div><h2>{title}</h2></div>;
    }
}

export default DwgList;
